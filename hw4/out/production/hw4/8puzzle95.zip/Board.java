import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Queue;


/**
 * Created by jia on 8/22/17.
 */
public class Board {
    private final int[] blocks;
    private final int N;
    private int blank = 0;


    // construct a board from an n-by-n array of blocks
    private Board(int[] blocks) {
        N = (int)Math.sqrt(blocks.length);
        this.blocks = blocks.clone();
    }

    public Board(int[][] blocks) {
        N = blocks[0].length;
        this.blocks = new int[N * N];
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                this.blocks[i * N + j] = blocks[i][j];
            }
        }
    }
    // (where blocks[i][j] = block in row i, column j)

    // board dimension n
    public int dimension() {
        return N;
    }

    // number of blocks out of place
    public int hamming() {
        int hammingCount = 0;
        for (int i = 0; i < N * N; i++) {
            if (blocks[i] != i + 1 && blocks[i] != 0) hammingCount++;
        }
        return hammingCount;
    }

    // sum of Manhattan distances between blocks and goal
    public int manhattan() {
        int manhattanCount = 0;
        for (int i = 0; i < N * N; i++) {
            if (blocks[i] != 0) {
                int col = Math.abs((blocks[i] - 1) / N - i / N);
                int row = Math.abs((blocks[i] - 1) % N - i % N);
                if (col != 0 || row != 0) manhattanCount += col + row;
            }
        }
        return manhattanCount;
    }

    // is this board the goal board?
    public boolean isGoal() {
        return hamming() + manhattan() == 0;
    }

    // a board that is obtained by exchanging any pair of blocks
    public Board twin() {
        Board twinedB = new Board(blocks);
//        for(int i = 0; i < N * N; i++) {

//        }
        if (blocks[ N * N - 1] != 0 && blocks[ N * N - 2] != 0) {
            exchg(twinedB.blocks, N * N - 1, N * N - 2);
        } else exchg(twinedB.blocks, 0, 1);
        return twinedB;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == null) return false;
        if (y.getClass() == this.getClass()) {
            Board yBoard = (Board) y;
            if (yBoard.dimension() == this.dimension()) {
                for (int i = 0; i < this.dimension() * this.dimension(); i++) {
                    if (yBoard.blocks[i] != this.blocks[i])
                        return false;
                }
                return true;
            }
        }
        return false;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        Board neibor;
        Queue<Board> queue = new Queue<>();
        for (int i = 0; i < blocks.length; i++) {
            if (blocks[i] == 0) {
                blank = i;
                break;
            }
        }


        if (blank >= N) {
                neibor = new Board(blocks);
                exchg(neibor.blocks, blank, blank - N);
                queue.enqueue(neibor);
        }

        if (blank < (N * N - N)) {
                neibor = new Board(blocks);
                exchg(neibor.blocks, blank, blank + N);
                queue.enqueue(neibor);
        }

        if (blank % N != 0) {
                neibor = new Board(blocks);
                exchg(neibor.blocks, blank, blank - 1);
                queue.enqueue(neibor);
        }

        if ((blank + 1) % N != 0) {
                neibor = new Board(blocks);
                exchg(neibor.blocks, blank, blank + 1);
                queue.enqueue(neibor);
        }

        return queue;
    }


    // string representation of this board (in the output format specified below)
    public String toString() {
        StringBuilder s = new StringBuilder();
        s.append(N);
        s.append("\n");
        for (int i = 0; i < N; i++) {
            s.append(" ");
            for (int j = 0; j < N; j++) {
                s.append(blocks[i * N + j]);
                if (j != N - 1){
                    s.append("   ");
                }
            }
            s.append("\n");
        }
        return s.toString();
    }

    private void exchg (int[] b, int x, int y) {
        int temp = b[x];
        b[x] = b[y];
        b[y] = temp;
    }

    // unit tests (not graded)
    public static void main(String[] args) {
    // create initial board from file
        // In in = new In(args[0]);
        In in = new In("8puzzle/puzzle3x3-10.txt");
        int n = in.readInt();
        int[][] blocks = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);
        Board test = new Board(blocks);
        System.out.println(initial.equals(test));
        System.out.println("hamming = " + initial.hamming());
        System.out.println("manhattan = " + initial.manhattan());
        System.out.println(initial.toString());
    }
}
