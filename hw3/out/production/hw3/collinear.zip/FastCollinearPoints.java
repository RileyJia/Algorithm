import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Arrays;

/**
 * Created by jia on 8/12/17.
 */
public class FastCollinearPoints {
    //private Point[] rest;
    private int elements;
    private double[] slope;
    private Point[] secCopy;
    private LineSegment[] s;
    private int num;
    private double[] lineSlpoe;
    private int[] lineElement;


    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {



        if (points == null) throw new java.lang.IllegalArgumentException("no argument");

        if (points.length == 0) throw new java.lang.IllegalArgumentException("argument is empty");
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null) throw new java.lang.IllegalArgumentException("argument is null");
        }
        Point[] copy = new Point[points.length];
        System.arraycopy(points, 0, copy, 0, points.length);

        Arrays.sort(copy);
        for (int i = 1; i < copy.length; i++) {
            if (copy[i].compareTo(copy[i-1]) == 0)
                throw new java.lang.IllegalArgumentException("repeated points");
        }


        elements = 0;
        s  = new LineSegment[0];
        lineElement = new int[0];
        lineSlpoe = new double[0];
        num = 0;



        for (int i = 0 ; i < copy.length; i++){

            secCopy = copy.clone();

            Arrays.sort(secCopy,copy[i].slopeOrder());

            slope = new double[copy.length];

            for(int j = 0; j < copy.length; j = j + elements - 1){
                elements = 2;
                slope[j] = copy[i].slopeTo(secCopy[j]);

                int end = j;
                int start = j;
                for (int k = j + 1; k < copy.length; k++) {
                    slope[k] = copy[i].slopeTo(secCopy[k]);
                    if (slope[j] == slope[k]) {
                        elements += 1;
                        end = k;
                    } else break;
                }

                if (elements >= 4) {
                    boolean realLine = true;
                    if (copy[i].compareTo(secCopy[start]) != -1) { realLine = false;}
                    if (realLine) {
                        num += 1;
                        LineSegment[] temp = new LineSegment[num];
                        System.arraycopy(s, 0, temp, 0, s.length);
                        s = temp;
                        s[num - 1] = new LineSegment(copy[i], secCopy[end]);
                    }
                }
            }
        }
    }

    // the number of line segments
    public int numberOfSegments(){
        return num;
    }

    // the line segments
    public LineSegment[] segments(){
        return s;
    }

    public static void main(String[] args) {

        // read the n points from a file

        //In in = new In(args[0]);
        In in = new In("input6.txt");
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();
    }
}
